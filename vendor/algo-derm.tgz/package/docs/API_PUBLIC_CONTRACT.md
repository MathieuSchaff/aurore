# Public API Contract

This document is the recommended integration contract for applications using
`algo-derm`. It describes the package surface that app code should depend on,
the payload to return from an app API, and the caveats that must stay visible to
users.

## Import Surfaces

`algo-derm` is the stable app-facing surface. Use it for runtime product
analysis, probabilistic scoring, compact summaries, product tags, ingredient
tags, and parsing helpers.

`algo-derm/engine` is an advanced surface for diagnostics or controlled
internal integrations. It remains intentionally unstable before 1.0: formulas,
helper semantics, and exported internals may change more often than the root API.
Do not make it the default app contract.

`algo-derm/devtools` is for offline diagnostics, fixtures, benchmarks, and
calibration utilities. Do not ship it as the runtime app contract.

Pre-1.0 policy: root API breaking changes should be called out in the changelog
and shipped with an explicit version bump. `/engine` and `/devtools` can move
faster while they are documented as advanced or offline surfaces.

## Which Function Should I Call?

Use the root package unless you are building maintenance tooling.

| Need | Call | Return this |
| --- | --- | --- |
| Product card, product detail page, or backend response | `analyzeINCI(...)` then `summarizeAssessment(...)` | `AssessmentSummary` |
| Audit screen or advanced partner integration | `analyzeINCI(...)` | `ProductAssessment` |
| Product-level badges such as `sans-parfum` | `tagProduct(assessment, ingredients)` | `ProductTag[]` |
| Ingredient-level badges such as fragrance or EU restriction | `ingredientTags(assessment)` | `IngredientTag[]` |
| Noisy scraped retailer INCI | `cleanInciString(...)` or `cleanInci(...)` before analysis | repaired string or ordered tokens |
| Canonical names for display/storage | `canonicalizeINCI(labels)` | canonical INCI labels |
| Single calibrated global-risk score | `analyzeProbabilistic(...)` | `ProbabilisticAnalysis` |

Default app flow:

```ts
const ingredients = splitINCI(rawInci);
const assessment = analyzeINCI(ingredients, options);
const summary = summarizeAssessment(assessment, { rawIngredients: ingredients });
```

Scraped catalogue flow:

```ts
const clean = cleanInciString(rawScrapedInci);
const ingredients = splitINCI(clean);
const assessment = analyzeINCI(ingredients, options);
```

Do not call `canonicalizeINCI(...)` just to improve scoring. The analyzer
already resolves known aliases internally; canonicalization is for display,
storage, or downstream matching in your app.

## Quick Start

`AssessmentSummary` is the recommended response shape for product cards,
product detail pages, and backend APIs. Keep `ProductAssessment` for advanced
inspection and debugging.

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

const rawInci =
  "Aqua, Glycerin, Niacinamide, Alcohol Denat, Parfum, Limonene";
const ingredients = splitINCI(rawInci);

const assessment = analyzeINCI(ingredients, {
  profile: { sensitiveSkin: true },
  context: { leaveOn: true, formulaType: "serum", estimatedPH: 5.5 },
});

const summary = summarizeAssessment(assessment, {
  rawIngredients: ingredients,
  includeIngredientTags: true,
});

console.log(summary.rating);
console.log(summary.confidenceLabel);
console.log(summary.coverage.ratio);
console.log(summary.topRiskDrivers);
```

## Function Reference

Every export of the root `algo-derm` surface, grouped by purpose: signature,
expected input, returned output.

**Analysis — INCI → assessment**

| Function | Input | Output |
| --- | --- | --- |
| `analyzeINCI(inci, options?)` | `string \| string[]`, `AnalyzeOptions` | `ProductAssessment` — full per-axis payload (risks, benefits, contributors, interactions, coverage, regulatory notes). |
| `analyzeProbabilistic(inci, options?)` | `string \| string[]`, `AnalyzeOptions` | `ProbabilisticAnalysis` — calibrated global risk `[0,1]` + CI + contributors. Same input contract as `analyzeINCI`. |
| `summarizeAssessment(assessment, options?)` | `ProductAssessment`, `AssessmentSummaryOptions` | `AssessmentSummary` — compact rounded app shape. Options: `rawIngredients` (needed to derive tags), `includeIngredientTags`, `includeAllProductTags`, `productTags`. |

**Tags — assessment → badges**

| Function | Input | Output |
| --- | --- | --- |
| `tagProduct(assessment, rawIngredients)` | `ProductAssessment`, `string[]` | `ProductTag[]` — product badges, tri-state `present \| absent \| insufficient_data`. |
| `ingredientTags(assessment)` | `ProductAssessment` | `IngredientTag[]` — per-ingredient signals (`fragrance`, `fragrance_allergen`, `eu_restricted`…). |

**Parsing & cleaning — string → tokens / keys**

| Function | Input | Output |
| --- | --- | --- |
| `splitINCI(inci)` | `string` (clean comma list) | `string[]` — ordered tokens (order carries the concentration signal). |
| `stripPreamble(inci)` | `string` | `string` — input without a supported simple label/preamble (`Ingredients:`, `Composition:`, `INCI:`). `FORMULE INCI` is handled by `cleanInciString(...)`, `cleanInci(...)`, and the raw-string `analyzeINCI(...)` path. |
| `normalize(value)` | `string` (one token) | `string` — lowercase matching key (FR→EN transliteration, diacritics/punctuation stripped). |
| `colorIndexLookupKey(label)` | `string` (one token) | `string \| null`: explicit CI identity key, or null without a code. `Iron Oxides (CI 77499)` yields `ci 77499`; multiple distinct codes stay a composite key and do not select one pigment. `normalize` uses this before removing glosses. CI 77891 selects pigment evidence; it does not establish UV-filter use or a catalog equivalence with the separate `Titanium Dioxide` evidence. |
| `canonicalizeINCI(labels)` | `string[]` | `string[]` — same length, each label → governed canonical INCI name; unknown passes through. Display/storage, not a prerequisite for scoring. |
| `cleanInciString(inci)` | `string` (scraped INCI) | `string` — repaired comma string (separators, labels, prose, legal). Display-preserving, idempotent. |
| `cleanInci(inci)` | `string` | `CleanInci` = `{ clean, ingredients, normalized, canonical }` — full pipeline in one call. |

**Claims & versioning**

| Function | Input | Output |
| --- | --- | --- |
| `buildKnownConcentrationsFromPackagingClaims(claims)` | `readonly PackagingConcentrationClaim[]` | `Record<string, number>` — `knownConcentrations` map (positive percentages only) for `context` or `options.packagingClaims`. |
| `TAG_DEFS_VERSION` | — (constant) | `number` — tag-definitions version; pin it consumer-side to detect a calibration change. |

`PackagingConcentrationClaim` needs at least one identifier (`ingredientSlug`,
`ingredientName`, or `inci`) plus a percentage: `concentrationPct` (preferred for
runtime payloads), or `concentrationValue` + `concentrationUnit` for corpus rows
(non-`%` units are ignored).

## analyzeProbabilistic

`analyzeProbabilistic(inci, options)` is the root-package wrapper for the
separate probabilistic scoring path. Use it when an application specifically
needs one global probability-like risk score with a confidence interval.

For ordinary app payloads, prefer `analyzeINCI(...)` plus
`summarizeAssessment(...)`: that path preserves per-axis risks, benefits,
drivers, product tags, ingredient tags, regulatory notes, coverage, and
declaration-only caveats.

```ts
import { analyzeProbabilistic, type ProbabilisticAnalysis } from "algo-derm";

const result: ProbabilisticAnalysis = analyzeProbabilistic(
  "Aqua, Glycerin, Retinol, Parfum",
  {
    profile: { sensitiveSkin: true },
    context: { leaveOn: true, formulaType: "serum" },
  },
);

console.log(result.globalRiskProbability); // ∈ [0, 1]
console.log(result.rating);               // "low" | "medium" | "high"
console.log(result.riskCI);               // { low, high }
console.log(result.contributors);         // per-ingredient probabilities
console.log(result.contraindicationsByProfile);
```

`ProbabilisticAnalysis` fields:

- `globalRiskProbability`: blended risk probability in `[0, 1]`.
- `riskCI`: confidence interval `{ low, high }` on the global probability.
- `rating`: `low | medium | high` from the probabilistic profile thresholds,
  independent of the PA calibration artifact. At the 2026-10-28 snapshot,
  probabilistic thresholds are `0.33/0.66`; `analyzeINCI` uses `0.43/0.66` from
  `data/calibration/current.thresholds.json` (fallback `0.33/0.66`).
- `confidence` and `confidenceLabel`: overall estimate reliability.
- `contributors`: per-ingredient breakdown (`IngredientProbability[]`).
- `notes`: coverage and uncertainty notices.
- `contraindicationsByProfile`: per-profile risk tier (`low | medium | high`) for
  `sensitive_skin`, `rosacea`, `acne_prone`, and `pregnancy`.

Same input contract as `analyzeINCI`: accepts `string | string[]`, all
`AnalyzeOptions` fields (`profile`, `context`, `packagingClaims`,
`evidenceDatabase`, `scoringProfile`, `asOfDate`), and throws the same
`RangeError`/`TypeError` on invalid
inputs.

**Heuristic-only caveat:** ingredients matched only via heuristic patterns
(fragrance molecules without a curated DB entry, unrecognised essential oils…)
are not scored by this path. A product with no curated matches returns
`rating "low"` and a coverage note. Use `analyzeINCI` when per-axis
explainability or heuristic signal coverage is required.

There is no `summarizeAssessment` equivalent for `ProbabilisticAnalysis`;
consume the fields directly. The lower-level engine function is named
`analyzeINCIProbabilistic(...)` and belongs to the advanced `/engine` surface,
not the default app contract.

## Input Contract

`analyzeINCI(inci, options)` and `analyzeProbabilistic(inci, options)` share
the same input contract. Both accept:

- `inci: string`: a raw comma-separated INCI declaration.
- `inci: string[]`: an already split, ordered ingredient list.

Order matters because INCI position is used as a concentration signal. Preserve
the packaging order when possible.

Important options:

- `profile`: user skin context, such as `sensitiveSkin`, `acneProne`,
  `rosacea`, or `pregnant`.
- `context`: product usage context. `leaveOn` defaults to `true` when the
  context is omitted; pass `false` for rinse-off products. `formulaType` and
  `estimatedPH` help exposure, concentration, interaction, and tag gating.
- `packagingClaims`: structured concentration claims such as "5% niacinamide".
  Explicit `context.knownConcentrations` entries take precedence over packaging
  claims.
- `scoringProfile`: named algorithm policy (`mainstream`, `conservative`, or
  `permissive`). Omitted means `mainstream`. The two alternative names currently
  preserve mainstream values until each receives a separately justified
  calibration; see ADR-0015.
- `asOfDate`: inclusive regulatory reference date in `YYYY-MM-DD` form.
  Omitted means the latest modeled state: undated and open-ended rules apply,
  while closed windows do not. The engine never uses the wall clock.

Invalid input policy for both entry points:

- `inci` must be a non-empty raw string or a non-empty ordered array of
  non-empty strings. Blank strings, empty arrays, and blank array entries throw
  `RangeError`. Non-string runtime values throw `TypeError` for JavaScript
  callers.
- `context.estimatedPH`, when present, must be a finite number in `0..14`
  inclusive.
- `context.knownConcentrations` values must be finite percentage numbers in
  `0..100` inclusive. Percent `packagingClaims` values follow the same range;
  non-percent claim rows are ignored by claim ingestion.
- `context.formulaType`, when present, must be one of `serum`, `cream`, `gel`,
  `cleanser`, `gentle_cleanser`, `lotion`, or `sunscreen`.
- `scoringProfile`, when present, must be `mainstream`, `conservative`, or
  `permissive`.
- `asOfDate`, when present, must be a real calendar date in `YYYY-MM-DD` form.

### Cleaning Real-World INCI

`splitINCI` and `analyzeINCI` assume a well-formed comma list. Catalogue data
scraped from retailer pages rarely is: it carries broken separators (pipe,
middle-dot, en-dash, underscore, period), leading labels (`Ingrédients :`,
`Composition :`, `FORMULE INCI :`), mid-string prose-then-header blurbs,
marketing claim prefixes (`SANS PARABÈNES…`), trailing legal disclaimers, and
glued multi-word tokens. Run the cleaner first:

```ts
import { canonicalizeINCI, cleanInci, cleanInciString } from "algo-derm";

// String-level repair only (display-preserving — keeps casing and real names):
const clean = cleanInciString(rawScrapedInci);
const assessment = analyzeINCI(clean, options);

// Or the full pipeline in one call:
const { clean, ingredients, normalized, canonical } = cleanInci(rawScrapedInci);
//   clean       repaired comma string
//   ingredients ordered tokens (splitINCI of clean)
//   normalized  canonical lowercase matching keys (normalize of each token)
//   canonical   each token mapped to its governed canonical INCI name

// Or map an already-split list to governed canonical INCI names (display/storage):
const names = canonicalizeINCI(["Vitamin B3", "BHA"]); // ["Niacinamide", "Salicylic Acid"]
```

`canonicalizeINCI(labels)` resolves each label to its canonical INCI name from
the curated alias registry; unknown labels pass through unchanged so a list is
never silently shortened. It is display normalization, separate from the
engine's evidence matching — `analyzeINCI` already resolves aliases internally,
so canonicalizing first is for storage/display, not a prerequisite for scoring.

`cleanInciString` is best-effort and idempotent: an already-clean list passes
through unchanged, so it is safe to call unconditionally. It does not enforce a
guardrail — callers writing results back to storage should compare token counts
before committing. Skip it when the input is already a trusted comma list.

## Recommended Output: AssessmentSummary

Return `AssessmentSummary` from application APIs unless the consumer genuinely
needs the full engine payload.

The summary includes:

- `rating`: `low | medium | high`.
- `overallRisk`: rounded bounded score in `0..1`.
- `confidenceLabel` and `confidenceScore`.
- `coverage`: matched, heuristic-only, unmatched, total, and ratio.
- `risks` and `benefits`: rounded axis scores with frontend-friendly names.
- `topRiskDrivers` and `topBenefitDrivers`.
- `productTags`: product-level badges, present-only by default.
- `ingredientTags`: optional per-ingredient badges when requested.
- `regulatoryNotes`, `unmatchedIngredients`, `declarationOnlyRisk`, and
  `limitationNotes`.

> **Language policy:** `limitationNotes` is mixed-language. Engine-emitted
> notes are in English; the summary layer appends the declaration-only note in
> French (the app-facing locale). Consumers must not assume a single language
> across the array.

The summary intentionally omits heavy engine fields such as `contributors`,
`matchedEvidence`, `heuristicFlags`, `interactions`, `regulatoryFindings`, and the internal
ingredient resolution object.

## Advanced Output: ProductAssessment

`ProductAssessment` is the full structured analysis result. It is useful for
internal tools, debugging, audit screens, and richer partner integrations. It
contains per-axis risks, confidence factors, contributors, matched evidence,
heuristics, interactions, structured `regulatoryFindings`, compatibility
`regulatoryNotes`, and coverage details.

Each `RegulatoryFinding` records the matching `ruleId`, region, classified
status, inclusive effective window, evaluated reference date, `matchedIngredients`
(all matched labels) and `subjectIngredients` (the subset the finding legally
classifies — the basis for regulatory ingredient tags), concentration/use
modifiers plus a compact `detail` string, display note, source IDs, and whether
the source was curated or official. Findings report matching legal signals; they
are not a compliance certificate. See
[`algorithm/regulatory-engine.md`](algorithm/regulatory-engine.md).

Treat numeric scores as tolerance-oriented risk signals, not clinical
probabilities or efficacy estimates.

### Conditional Citrus Checks

`analyzeINCI` adds optional `citrusRisk` for the six canonical oils in
[ADR-0025](adr/0025-citrus-dose-risk-decoupling.md). Governed aliases resolve to
these identities. Each oil reports `identityQualification: "confirmed" | "unconfirmed"`.
Only an exact normalized canonical name, authored alias or alias override confirms
identity. A botanical fallback remains a candidate with all four checks
`indeterminate` (`ingredientIdentityUnconfirmed`); it cannot contribute a
qualified analytical measurement. An exact occurrence does not qualify another
ambiguous occurrence of the same oil. Identity qualification preserves parenthetical
botanical qualifiers; only common-name parentheses appropriate to that oil, such
as `(Lemon)`, are ignored. Unrecognized annotations remain unconfirmed unless
explicitly authored as an alias. With a custom evidence database lacking the oil,
identity must still match its canonical material name under the same qualifier
check; missing evidence never confirms identity on its own. Unrelated botanical
parts are not certified.
`summarizeAssessment`
preserves this object without rounding. It survives JSON serialization. The
probabilistic API validates the input shape but does not emit these checks.

Supply `context.citrusRisk` independently of solver inputs:

```ts
const result = analyzeINCI("Aqua, Citrus Aurantium Bergamia Peel Oil", {
  context: {
    leaveOn: true,
    citrusRisk: {
      standardVersion: "IFRA-51",
      source: "formulation dossier: category, exposure, complete mixture",
      ifraCategory: "5B",
      uvExposedSkin: true,
      otherPhototoxicSourcesAbsent: true,
      materials: {
        bergamot: {
          source: "formula and supplier certificate",
          lotId: "example-lot",
          extraction: "expressed",
          nonVolatileConcentrationFactor: 1,
          concentrationPct: 0.2,
        },
      },
    },
  },
});
// result.citrusRisk.phototoxicity.status: "withinLimit" for this criterion only.
// Oxidation, allergy and irritation remain indeterminate in this example.
```

Exported types: `CitrusRiskInput`, `CitrusMaterialInput`, `CitrusOil`,
`CitrusAllergen`, `CitrusCheck`, `CitrusRiskAssessment`. The six material keys are
`lime`, `bitterOrange`, `bergamot`, `sweetOrange`, `lemon`, `grapefruit`.

Checks return `status`, machine-readable `reason`, primary `sourceUrls` and
caller `inputSources`, plus `value`, `limit`, `unit` when evaluable. Statuses:
`withinLimit`, `exceedsLimit`, `indeterminate`, `notApplicable`, and the separate
allergy match `matchesDeclaredAvoidance`. No status certifies overall safety,
legal compliance or absence of allergy. `notApplicable` concerns the named
criterion only. Irritation remains `indeterminate`: no qualified formulation
model is available. These checks do not change scores, solver concentrations,
benefits, regulatory findings or tags. `legacyRiskQualification` stays
`unvalidated`; the current `TAG_DEFS_VERSION` is 32.

Policy `citrus-conditional-v4` pins `referenceVersion: "IFRA-51"` and
`sourcesReviewedOn: "2026-10-29"`. This is an explicit historical reference,
not an automatic determination of the current applicable standard. Missing or
unsupported versions, including `IFRA-52`, yield indeterminate normative checks.
`AnalyzeOptions.asOfDate` remains specific to the legal regulatory engine.
The future IFRA policy is not implemented.
Version 2 corrected five false-positive paths in the initial local version 1.
Version 3 also retains botanical qualifiers hidden in parentheses and blocks
mixture passes with visible free bergapten. Version 4 also enforces identity
qualification when a custom database has no matching evidence. Stored version-1,
version-2 and version-3 checks must not be treated as equivalent to version 4. The conditional checks do not alter score/tag calculations or qualify the legacy risk rule.

Phototoxicity requires a documented IFRA category and UV skin exposure. Categories
7A, 9, 10A, 11A and 12 fall outside this restriction; `leaveOn` alone cannot infer
a category. A restricted category with `leaveOn: false` stays indeterminate.
Categories 7A and 9 with `leaveOn: true` also stay indeterminate.
Category 11A with `uvExposedSkin: true` is an explicit conflict and returns
`indeterminate` (`ifraCategoryUvConflict`), rather than an exemption.
Known absence of UV skin exposure excludes only this phototoxicity check.

Without a supplied assay, the default `phototoxicityRoute: "oilLimits"` requires lot identity, extraction,
declared percentage and nonvolatile concentration factor. A factor of 1 must be
documented, not assumed. Lemon requires `coldPressed`; the other four capped
oils accept `expressed` or `coldPressed`. `distilled` and `other` do not receive
an automatic exemption. The five limits are divided by the declared factor;
sweet orange has no qualified individual limit. FCF wording alone supplies no
analytical information. The mixture uses the sum of concentration/adjusted-limit
fractions. All relevant sources must be covered to establish `withinLimit`;
a known excessive subset can already establish `exceedsLimit`.

For `phototoxicityRoute: "bergapten"`, each lot supplies
`bergapten: { ppm, basis, method, methodAppropriate, source }`. `ppm` is 5-MOP in
the oil, not total furocoumarins or finished-product ppm; `basis` is `measured`
or `upperBound`. `methodAppropriate: true` is the caller's documented assertion
of an appropriate assay, not software validation of the method. The module sums
`concentrationPct * ppm / 100` and checks 15 ppm in the finished product.
Analytical upper bounds can establish a pass; crossing the limit with a bound
alone is indeterminate. Positive measured contributions above the limit establish
an exceedance. Individual oil caps are marked `notApplicable` on this alternative
route and point to the mixture result, which can itself be indeterminate.
Any supplied `bergapten` object selects this route, even when the caller requests
`oilLimits`. The returned `phototoxicityRoute` is the effective route; the input
is not mutated. Incomplete assays conservatively remain indeterminate instead
of falling back to a favorable oil cap. A qualified measured subset exceeding
15 ppm still establishes an exceedance. Complete low assays can establish a pass
even above the fallback oil cap; the two criteria are not mechanically combined.

Both routes require `otherPhototoxicSourcesAbsent: true` with dossier provenance
to establish a complete mixture pass. This attests that all relevant sources
are represented by the supplied lots, including sources hidden in fragrance
mixtures. The module does not verify certificates, discover all photoactive
constituents from INCI, or evaluate the other materials in STD089. A guard checks
raw and resolved names for its named outside oil sources (angelica root, cumin,
rue, petitgrain mandarin, tangerine and parsley leaf), and for free `Bergapten`
or `5-Methoxypsoralen`. The free analyte is not covered by an oil-lot assay.
Their visible presence
prevents a mixture pass even if the caller attests absence; the result is
`indeterminate` (`unaccountedPhototoxicSource`). A known excessive subset remains
actionable. This guard is not exhaustive constituent discovery. If outside
sources exist or their absence cannot be documented, omit the attestation.
One lot per canonical oil is supported; multi-lot formulations require separate
evaluation. Duplicate aliases do not create additional lots or contributions.

Oxidation is a material-quality criterion, independent of phototoxicity. Supply
`oxidation: { substantialLimoneneOrLinalool, peroxideValueMmolPerL, method, source }`
on the lot. The numeric check requires a documented substantial-constituent
assessment and `method: "IFRA"`; the limit is strictly below 20 mmol/L. It does
not prove that oxidation is at the lowest practical level or that allergy is
absent. Missing information stays indeterminate; no universal substantial-content
threshold is invented.

`declaredAllergies` matches only `limoneneHydroperoxides` and
`linaloolHydroperoxides` against explicit lot `allergens` booleans. Omission means
unknown; a documented positive matching an avoidance yields
`matchesDeclaredAvoidance`, not a clinical probability or an automatic exclusion.
An empty declared list means no avoidance to match. Other allergens remain outside
this narrow contract. Missing formulation evidence leaves irritation unqualified.

All values are caller supplied, never independently verified. Neither
`knownConcentrations`, packaging claims nor INCI estimates silently populate
these checks. Documentary percentages do not pin the dose solver either.
Malformed values (nonfinite/negative measurements, percentage above 100, invalid
enums, unknown fields) and material keys absent from the resolved INCI are rejected.
All documentary records must be plain objects (ordinary or null prototype)
containing only own, enumerable data properties. Inherited fields, hidden fields,
accessors and symbol keys are rejected, so unvalidated values cannot reach the
comparisons. These checks apply recursively to the nested documentary records.
Legitimately missing optional fields yield `indeterminate`.
See the [primary-source qualification](audit/legacy-v42-risk-qualification-2026-10-29.md)
and [IFRA matrix](audit/citrus-ifra-primary-qualification-2026-10-29.md).

### Benefit Magnitude And Evidence Confidence

Since version 27, six citrus oils carry `dosePrior: { kind: "positionOnly", qualification: "heuristic" }`
and `riskDoseModel: { kind: "legacyV42", qualification: "unvalidated" }` in matched evidence.
Their concentrations add optional `doseBasis: "positionOnly" | "declared"` and
`intervalQualification: "uncalibrated" | "declared"`. These describe `solverMeanPct`
and `solverCi*` when present, otherwise `meanPct` and `ci*`. Historical pre-solver
fields remain heuristic when a claim pins the solver. Declared means supplied,
not independently verified; collapsed intervals are pins, not statistical coverage.
Both API paths retain this provenance. Product-assessment limitation notes state
the risk rule's unvalidated status and, when inferred, the dose uncertainty.
The probabilistic risk path remains dose-independent. See
[ADR-0025](adr/0025-citrus-dose-risk-decoupling.md) for identities and migration limits.

Since `TAG_DEFS_VERSION = 26`, each `productBenefits[axis].benefit` is the
strongest ingredient signal on that axis, or zero without positive drivers.
Signals incorporate grade, evidence quality, concentration and exposure.
At fixed remaining signals, removing a weak driver cannot raise the magnitude.
The pH-masked replay uses the same aggregation. Risks retain their own rules.

`productBenefits[axis].confidence` remains the mean evidence quality of positive
drivers, independent of product coverage. Removing a low-quality driver may
raise that confidence. Neither the confidence nor all downstream tags are
guaranteed monotone. The seven axes and serialized output shapes are unchanged.
See [ADR-0024](adr/0024-monotone-benefit-aggregation.md).

## Confidence, Coverage, And Declaration-Only Risk

`confidence` estimates how much support the engine has for the submitted INCI
list. It drops when many ingredients are unknown or heuristic-only.

`coverage.ratio` is the matched curated-evidence ratio over the submitted list.
Low coverage means the product may still have a score, but the result should be
shown with caution.

`declarationOnlyRisk` is an informational caveat for tail-declaration patterns.
It does not change `overallRisk` or `rating`, but applications should expose
it through `limitationNotes` or a nearby warning when present.

Recommended display caveats:

- Show a low-confidence caveat when `summary.confidenceLabel === "low"`.
- Show a low-coverage caveat when `summary.coverage.ratio < 0.6`.
- Show the declaration-only caveat when `summary.declarationOnlyRisk` is true.
- Keep regulatory notes informational; do not present them as a compliance
  certificate.

## Tags

The current checkpoint is `TAG_DEFS_VERSION = 32`. The `peaux-sensibles` and
`peau-sensible` tags abstain only when their numerical predicate depends on
attenuating a positive C/D irritation or allergenicity grade. The sensitivity
diagnostic removes that evidence weight at fixed dose, exposure, profile,
heuristics and interactions. Existing thresholds and coverage/confidence floors
remain unchanged. Other risk-based tolerance tags retain the v29 C/D gate.

`productAxisRisk[axis].riskWithoutWeakEvidenceDiscount` is optional and present
on irritation/allergenicity when a relevant positive C/D grade is matched.
It is a sensitivity diagnostic, not an estimated risk, confidence interval,
safety bound or user-facing score. It survives JSON serialization. Assessments
without this diagnostic retain the v29 abstention when relevant C/D grades exist.
Risk scores, benefits and their drivers are unchanged. This does not establish
monotonicity within A/B, against concentration changes, or clinical suitability.
The Gardenia soothing grade remains withdrawn; risk grades and citrus policy
remain unchanged. Changes to curated evidence
and aggregation can change tags even when definitions and thresholds stay the
same. Audit consumer outputs and benefit floors before updating a calibrated
version guard; the [migration guide](aurore/V26_BENEFIT_MIGRATION.md) records the
v25/v26 changes and pending validation. A version increment is not proof of
clinical calibration.

Product tags from `tagProduct(...)` and `summarizeAssessment(...)` use a
tri-value state:

- `present`: the product qualifies for the tag under current evidence and
  context.
- `absent`: the product does not qualify.
- `insufficient_data`: coverage, confidence, or product context is not strong
  enough to support the positive claim.

`present` remains a back-compatible boolean equal to
`state === "present"`. Prefer `state` in new integrations.

Ingredient tags from `ingredientTags(...)` identify ingredient-level signals
such as fragrance, fragrance allergens, essential oils, and regulatory
restriction/prohibition notes. Regulatory tags project each finding's
`subjectIngredients`, so they cover both curated ingredients and ingredients
flagged only by the official lookup. They are useful for ingredient badges and
filters, but they are not standalone risk scores.

## Backend API Example

```ts
import { analyzeINCI, splitINCI, summarizeAssessment } from "algo-derm";

export const assessProductINCI = (rawInci: string) => {
  const ingredients = splitINCI(rawInci);
  const assessment = analyzeINCI(ingredients, {
    context: { leaveOn: true, formulaType: "cream" },
  });

  return summarizeAssessment(assessment, {
    rawIngredients: ingredients,
    includeIngredientTags: true,
  });
};
```

This keeps the public API payload compact while preserving caveats, tags, top
drivers, coverage, and regulatory notes.

## Limits To Keep Visible

The library does not provide:

- medical diagnosis;
- treatment advice;
- clinical efficacy prediction;
- guaranteed regulatory compliance;
- exact formula reconstruction;
- complete routine-level interaction modeling.

Use language such as "tolerance signal", "risk-oriented signal", "ingredient to
watch", and "coverage/confidence caveat". Avoid absolute marketing claims such as
"safe", "hypoallergenic", "non-irritating", "non-comedogenic", or "pregnancy
safe" unless the surrounding UI preserves the tag state and caveats.

## Package Contents And Budget

The runtime package is expected to include:

- `dist/` JavaScript and declaration files;
- `data/ingredients/ingredient_evidence.merged.json`;
- `data/inci/` runtime INCI alias registry;
- `data/rules/` runtime rules and normalization data;
- `data/regulatory/regulatory.lookup.json`;
- `data/regulatory/CELEX_02009R1223-20260501_FR_TXT.regulatory.json`;
- `README.md`, `LICENSE`, and this public contract.

Current budget for the packed package:

- compressed size: <= 890,000 bytes;
- unpacked size: <= 6 MB.

`npm run test:package` enforces the package import contract and these package
content expectations from a locally installed tarball.


## Optional declarations (contract 31)

`analyzeINCI` preserves `+/-`, `±`, `may contain` and `peut contenir` as
optional presence, including scoped bracket lists. Pass the raw declaration,
or an ordered array that still contains its markers. `splitINCI` remains a
flattened identity list for compatibility; a caller that discards the markers
before analysis cannot recover optional presence.

`optionalIngredientCoverage`, present only for marked declarations, records
optional names and zero-based indices, `minimumRatio` and `minimumConfidence`.
Coverage is minimized by removing recognized optional ingredients and retaining
unrecognized optional ingredients. Confidence is the minimum over optional
subsets under the existing evidence/heuristic/unknown weighting. The computation
sorts contributions instead of enumerating every subset. Empty variants yield
zero. Positive tolerance tags use the existing 0.6 coverage and 0.5 confidence floors.
Each risk axis additionally exposes `confidenceAcrossOptionalSubsets`, combining
minimum driver evidence quality and minimum coverage at the submitted dose
context. The existing choice between axis confidence and the product fallback is
preserved: low global confidence alone must not veto a supported axis signal.
JSON round trips retain the gate. A sufficiently supported
mandatory formula can still receive the tag. Possible ingredients remain in the
assessment and warning checks.

These are evidence coverage/confidence bounds, not bounds on risk scores, dose,
interactions or efficacy across shade variants. Numerical assessments still
represent the submitted possible ingredient list. The probabilistic API shares
parsing but does not expose these tolerance-tag diagnostics. No product identity,
brand statement or shade exception participates in the rule.

## Undisclosed aromatic mixtures (contract 32)

`Aroma`, `Flavor` and `Flavour` leave the constituents unknown. Otherwise
positive `sans-parfum`, `sans-allergenes-parfumants` and
`sans-huiles-essentielles` become `present: false`, `state: insufficient_data`.
An observed trigger keeps `state: absent` and its confidence. This is an
abstention, not an inferred allergen or essential oil. Other absence tags,
numerical assessments and the existing Parfum/Fragrance policy are unchanged.


### Composite color-index declarations

Both public analysis paths expand a closed `Iron Oxides (CI 77491, CI 77492,
CI 77499)` declaration into its exact known identities. Commas and slashes,
implicit CI prefixes, declared order and optional presence are supported.
Contract 34 accepts trailing asterisks after `)`, with optional whitespace.
Raw provenance retains them without inferring sourcing, certification, dose or
optional presence. Internal asterisks and other suffixes remain unsupported.
Repeated codes within one group count once. Separate declared occurrences remain
separate. Coverage and concentration positions refer to the expanded list.
The optional `colorIndexDeclarations` field on either result records each raw
`declaration`, expanded `ingredients` and `optional` flag. Preserve it through JSON
when calling `tagProduct` with the original raw declarations.

Expansion is atomic and bounded to those three iron oxides. Unknown members,
unsupported suffixes, square-bracket identity glosses, nano-qualified composites
and groups with a collective concentration pin remain unresolved. A per-member
pin applies only to that identity. No collective dose is assigned to each member.
Unclosed iron-oxide CI groups stay atomic before matching; independent ingredients
after the contiguous CI members remain separate. The single-identity lookup still
refuses multiple distinct codes. The source text is never rewritten.

## Distinct polymer declarations (contract 35)

`Polybutene` is not an unconditional alias of `Polyisobutene`. Canonicalization
preserves the declaration; default evidence lookup leaves it unresolved rather
than assigning Polyisobutene evidence, CAS or concentration bounds. This also
applies to both public analysis APIs. `Polyisobutene` and
`Hydrogenated Polyisobutene` retain their separate existing entries.

CIR Table 1 distinguishes these INCI definitions and CAS identifiers:
[final report, pages 63S and 64S](https://journals.sagepub.com/doi/pdf/10.1177/1091581820952385).
Industrial synonym usage does not justify universal cosmetic INCI substitution.
No Polybutene evidence profile is added by this correction. Replay derived
outputs before adopting this package; do not globally rewrite stored formulas.
