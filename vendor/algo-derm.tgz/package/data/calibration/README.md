# Rating threshold artifact

`current.thresholds.json` is the versioned source of the active
`productAssessment.overallRisk` rating cuts used by `analyzeINCI`.

Schema version 1 contains:

- `predictor`: must be `productAssessment.overallRisk`;
- `rating.lowMax`: values below this cut are `low`;
- `rating.mediumMax`: values below this second cut are `medium`, otherwise
  `high`;
- `provenance`: stable calibration id, generation timestamp, corpus name,
  corpus support, and per-cut status (`calibrated` or `legacy_default`).

Both cuts must be finite values in `0..1` and `lowMax < mediumMax`. If the file
is absent, unreadable, or invalid, the engine safely falls back to the legacy
cuts `0.33/0.66`.

The active artifact calibrates `lowMax` on the expert-locked train/validation
set and keeps `mediumMax` at the legacy `0.66` cut. The high band does not yet
have enough support for an honest replacement cut.

## Recalibration workflow

1. Run `npm run calibrate:pa-thresholds -- --corpus <gold.json> --locked-only --report <report.json>`.
2. Review the report, class support, held-out rank agreement, and proposed cuts.
3. Once the corpus satisfies the expert-locked rank gate, rerun with
   `--write-current`. This calibrates `lowMax` and freezes the under-supported
   high cut by default.
4. Use `--write-current --calibrate-high` only after every band satisfies the
   balance gate.
5. Review the artifact diff and run `npm run check:all`.

For a non-mutating verification of the activation path, combine
`--write-current` with `--current-artifact /tmp/current.thresholds.json`.

The probabilistic calibration command (`calibrate:thresholds`) deliberately
does not write this artifact: its predictor is different and remains
independently calibrated per ADR-0001.
