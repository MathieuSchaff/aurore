# data/inci/

Single governed source for canonical INCI ↔ alias mappings. Feeds both
parser normalization and the evidence matcher, so an edit here can change which
ingredient a declared name resolves to. Review like code.

## Objectif final

Tout ingrédient présent dans la liste INCI d'un produit doit être **reconnu et
catalogué** par les algorithmes : oui, il est référencé ; oui, le moteur l'a vu
et rangé là où il faut. C'est le rôle de ce dossier (registre de noms) couplé à
la base de preuves (`data/ingredients/`).

Pour les ingrédients principaux, on va plus loin : une **fiche encyclopédique**
(style Wikipédia) à laquelle on n'a qu'à se rendre pour comprendre l'ingrédient
d'un coup d'œil — ce qu'il fait, son nom INCI, s'il est régulé, et toutes les
informations utiles au même endroit.

Le principe : **stocker tout, n'afficher que l'utile**. On conserve, même si on
ne l'affiche pas forcément :

- les **alias** et autres orthographes / appellations de l'ingrédient ;
- son **nom dans la loi** (libellé réglementaire UE / Canada) ;
- ses **numéros d'identité** (CAS, EC, références d'annexes) ;
- ce que les **sources officielles disent de sa fonction** — CELEX et CosIng
  décrivent parfois déjà à quoi sert l'ingrédient ; on capte cette information.

Les sources primaires nécessaires à ce stockage (textes légaux, glossaires,
avis SCCS, Hotlist Canada) sont rassemblées dans `wheretofind/` (carte des
sources + playbooks de sourcing) et dans les PDF réglementaires de ce dossier.

## Files

| file                               | role                                                                                                  | consumed by                                                     | git                |
| ---------------------------------- | ----------------------------------------------------------------------------------------------------- | --------------------------------------------------------------- | ------------------ |
| `aliases/aliases.jsonl`            | source of truth: one object per ingredient mapping a canonical INCI name to its alias spellings       | `scripts/lib/inciAliases.ts` loader (build/normalization paths) | tracked, published |
| `aliases/aliases.generated.json`   | `require()`-able twin of the JSONL, keyed by slug; runtime source for `canonicalizeINCI`              | `src/parsing/inciCanonical.ts`                                  | tracked, published |
| `cosing/lookup.json`               | EU CosIng inventory (~26 K entries), keyed by `normalize()`'d INCI → `{ ref, inciName, synonyms?, functions?, cas?, ec? }` | harmonization tooling                        | gitignored, derived |
| `cosing/cosing_batch.json`         | 50-ingredient pilot workfile with CosIng identity + disposition bucket                               | manual review / `build-cosing-classification-batch.ts`          | gitignored         |
| `cosing/cosing_pilot_buckets.json` | classified pilot (50): alias_to_curated=1 / harmonize_only=17 / curate=30 / ignore=2                 | reference                                                       | gitignored         |
| `cosing/cosing_scale200_buckets.json` | classified scale batch (150): harmonize_only=45 / curate=103 / ignore=2                           | reference                                                       | gitignored         |
| `cosing/reports/coverage_gaps.report.json` | gap analysis: 3 717 distinct unmatched INCI tokens, 24.7% unmatched rate across all corpora  | reference                                                       | gitignored         |
| `CELEX_01996D0335-20060209_EN_TXT.pdf` | consolidated EU INCI inventory (Decision 96/335/EC, as of 2006-02-09); working copy for name/identity curation | manual reference (see `wheretofind/`)        | tracked            |
| `wheretofind/`                     | regulatory source map + sourcing playbooks + primary legal/glossary documents (see section below)     | manual curation                                                | mixed (see below)  |

## Schema

### `aliases/aliases.jsonl` — one JSON object per line

| field            | meaning                                                                 |
| ---------------- | ----------------------------------------------------------------------- |
| `canonicalInci`  | canonical INCI name the entry resolves to                               |
| `aliases`        | optional alias spellings folded into the canonical name during matching |
| `aliasOverrides` | optional subset of `aliases` that also overrides generic normalization  |

Line order is significant: collisions resolve to the first matching entry, and
the generated twin preserves that order.

### `aliases/aliases.generated.json`

Object keyed by slug → `{ canonicalInci, aliases?, aliasOverrides? }`, mirroring
each JSONL row. Generated, never hand-edited.

## Coverage state

As of the last gap analysis (`cosing/reports/coverage_gaps.report.json`):

- **782** curated ingredients in `data/ingredients/ingredients.jsonl`
- **3 717** distinct INCI tokens unmatched across all corpora (24.7% unmatched rate)
- Aurore corpus: 1 107 unmatched / 7 200 tokens
- Sephora corpus: 11 087 + 5 705 unmatched / 45 400 tokens

The 200-ingredient classified backlog (`cosing_scale200_buckets.json`) breaks down as:

| disposition      | count | action required                                              |
| ---------------- | ----- | ------------------------------------------------------------ |
| `alias_to_curated` | 1   | add alias to `aliases.jsonl` only (ingredient already curated) |
| `harmonize_only`   | 62  | add entry to `aliases.jsonl` (CosIng confirms identity, no curation needed) |
| `curate`           | 133 | full curation in `data/ingredients/ingredients.jsonl`        |
| `ignore`           | 4   | solvents / pH adjusters / non-cosmetic actives               |

## Editing

Edit alias spellings in `aliases/aliases.jsonl` only, then regenerate the twin:

```text
npm run build:inci-aliases   # aliases/aliases.jsonl -> aliases/aliases.generated.json
```

Do not add ingredient-specific aliases to `rules/`; this directory is the only
governed source. After any edit run `npm run check:all` (the generated twin must
stay in sync, or the deterministic-data gate fails).

`aliases.jsonl` is the sole alias source of record. A legacy slug-keyed dump
(`alias.ts` / `ingredient-slugs.ts`) was mined for genuine trade/common-name
synonyms and retired (2026-06-12) — do not resurrect it; add new aliases here.

## CosIng lookup

`cosing/lookup.json` is the deterministic spelling authority for INCI
harmonization (the LLM proposes an identity; CosIng confirms the canonical
orthography). It is derived, not governed, so it stays out of `check:all`: its
source CSV lives in the license-unverified `data/external/` and is not committed.
Regenerate from a local copy of that CSV:

```text
npm run extract:cosing   # data/external/cosing_*.csv -> cosing/lookup.json
```

Lookup keys use the canonical `src/parsing/normalize`, matching the runtime query
path — do not re-implement normalization in the build script.

## Scripts

| command | script | produces |
| ------- | ------ | -------- |
| `npm run build:inci-aliases` | `scripts/build-inci-aliases-json.ts` | `aliases/aliases.generated.json` |
| `npm run extract:cosing` | `scripts/extract-cosing.ts` | `cosing/lookup.json` (requires local CosIng CSV in `data/external/`) |
| `npm run build:cosing-batch` | `scripts/build-cosing-classification-batch.ts` | batch workfile at `/tmp/cosing_batch.json` (reads `cosing/lookup.json` + `coverage_gaps.report.json`) |
| `node --import tsx scripts/analyze-coverage-gaps.ts` | `scripts/analyze-coverage-gaps.ts` | `cosing/reports/coverage_gaps.report.json` (gap analysis across all corpora) |
| `node --import tsx scripts/audit-coverage.ts <products-inci.csv>` | `scripts/audit-coverage.ts` | stdout — matched/heuristic/unmatched breakdown from CSV |
| `node --import tsx scripts/audit-db-coverage.ts <backup.sql>` | `scripts/audit-db-coverage.ts` | stdout — coverage audit from a pg COPY SQL backup, optional `--out reports/audit.txt` |

## Coverage expansion workflow

Two levers to reduce the 24.7% unmatched rate:

**1. Alias-only (fast)** — for `harmonize_only` dispositions: add a line to
`aliases.jsonl` mapping variant spellings to the canonical INCI, then
`npm run build:inci-aliases`. No evidence curation needed.

**2. Full curation (slower)** — for `curate` dispositions: run
`npm run dossier "<INCI NAME>"` to generate a scored workfile in
`data/ingredients/dossiers/`, review it, then promote to
`data/ingredients/ingredients.jsonl`. Rebuild with `npm run build:dataset &&
npm run merge:dataset`.

See `docs/INGREDIENT_HARMONIZATION_PLAN.md` for the full CosIng-driven strategy
and `wheretofind/SYSTEM.md` for the dossier sourcing playbook.

## Regulatory source documents (`wheretofind/`)

Primary, offline copies of the official sources backing curation — so a "banned /
restricted / regulated" decision rests on the **legal text**, not a blog. The
maps tell you *where to look*; the PDFs are the *looked-up sources* kept locally
for reproducibility.

### Maps & playbooks (markdown)

| file                          | role                                                                          |
| ----------------------------- | ----------------------------------------------------------------------------- |
| `README.md`                   | decision map: jurisdiction + info type → official source (EUR-Lex annex, CosIng, SCCS, ECHA, Canada Hotlist); distinguishes legally-binding vs informative |
| `SYSTEM.md`                   | reproducible per-script sourcing pipeline (`npm run dossier "INCI"` — identity + regulatory + evidence) |
| `ingredients.md`              | terminal-friendly identity/evidence APIs (PubChem, NCI Cactus, Open Beauty Facts, PubMed, ChEMBL, EPA CompTox) + ready-to-run curl scripts |
| `ressources.md`               | raw EUR-Lex / PCPC URLs for the legal texts below                             |
| `etape6-curation-workflow.md` | étape-6 curation workflow notes                                               |

### Primary legal & glossary documents (PDF / txt, local copies)

| file                                    | document                                                                 | use                                          |
| --------------------------------------- | ------------------------------------------------------------------------ | -------------------------------------------- |
| `CELEX_31996D0335_EN_TXT.pdf`           | Commission Decision 96/335/EC — historical EU cosmetic ingredient inventory | INCI names, identity                      |
| `CELEX_32019D0701_EN_TXT.pdf`           | Decision 2019/701 — glossary of common ingredient names for labelling (repealed, superseded by 32022D0677) | common labelling names (superseded) |
| `glossary-2022D0677/32022D0677_EN.html` | Decision (EU) 2022/677 — current EU glossary of common ingredient names for labelling (raw EUR-Lex HTML, ~10 MB); supersedes 2019/701 | controlled vocab of valid labelling names → alias allowlist; gitignored, re-fetch from `CELEX:32022D0677` |
| `CONSLEG_1976L0768_20120823_FR_TXT.pdf` | Directive 76/768/EEC (consolidated) — former Cosmetics Directive         | historical legal context                     |
| `OJ_L_1996_132_FULL_EN_TXT.pdf` / `_FR_TXT.pdf` | Official Journal L 132 (1996), full — carries Decision 96/335     | source-of-record for 96/335                  |
| `sccs_o_199.pdf`                        | SCCS scientific opinion                                                   | toxicological justification for a restriction |
| `canada-prohibited.txt`                 | Health Canada Cosmetic Ingredient Hotlist export                         | Canada prohibited/restricted status (`regulatoryStatusByRegion.CA`) |

The markdown maps are tracked; the large PDFs are heavyweight local working
copies — keep them out of `check:all` and review before committing (some exceed
30 MB). The authoritative consolidated 1223/2009 copy used by the runtime adapter
lives separately in `data/regulatory/`.

### PCPC INCI Dictionary supplements (naming authority — not regulatory)

Issued by the Personal Care Products Council / International Nomenclature
Committee, which *assigns* INCI names. These are the **identity & spelling**
authority (how a name is formed and how it changed over time), distinct from the
EU/Canada legal texts above (what is allowed). Their value to this directory is
**alias and normalization fuel**, not regulatory status — most map directly onto
`aliases/aliases.jsonl` and `src/parsing/normalize`.

| file                              | document                                                                                       | use                                                                 |
| --------------------------------- | ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `INCI-Nomenclature-Conventions.pdf` | the systematic INCI naming rules (general/specific/misc conventions)                        | spec for normalization: PEG/PPG/PEI forms, chain-length stems (C6→Caproic/Hexyl), `iso` prefix, slash = mixture (not blend), `Pareth` = even+odd alkyl, grandfathered names, Water = Water |
| `COSING_Abbreviations.pdf`        | chemical-abbreviation table (AEEA, AMP, BHA/BHT, DEA, EDTA, PCA, PEG/PPG/PEI, TEA, …)           | alias expansion — recognize/expand abbreviated forms                |
| `CurrentINCIChanges.pdf`          | Former → New INCI name table with `MonoID`, current rolling window                             | alias source (old spelling → canonical); `MonoID` is a candidate ID backbone (see audit P0) |
| `NameChanges16_20.pdf`            | Former → New INCI name table with `MonoID`, 2015-09 → 2021-03                                  | alias source (bulk historical renames)                              |
| `RetiredINCINames.pdf`            | retired → new INCI names (e.g. Ceramide 1 → Ceramide EOP, Algae → genus/species)               | alias source for legacy labels still seen on packaging              |
| `Typographical.pdf`               | misspelled → corrected INCI names (e.g. Atractyloides → Atractylodes)                           | normalization source — fold known typos to canonical               |
| `INCINamesforHydrocarbons.pdf`    | isoparaffin → isoalkane, pareth → alketh transition (REACH-aligned, through 2025)              | hydrocarbon alias source                                            |
| `Cannabis-Info-for-Website_final.pdf` | INCI naming for *Cannabis sativa* derivatives ("hemp" dropped from names)                   | niche identity reference                                            |

`MonoID` in the change tables is the PCPC monograph identifier — a stable
per-ingredient ID that survives renames, hence a concrete candidate for the
"ID backbone" the audit (below) calls for under P0.

`NameChanges16_20 (1).pdf` is a byte-identical duplicate of `NameChanges16_20.pdf`
(verified with `cmp`) — drop it.

## Écarts actuels vs objectif (audit 2026-06-11)

État mesuré sur les données réelles, confronté à l'« Objectif final » ci-dessus.

> **Mise à jour 2026-06-11 — P0 réalisé** (`docs/adr/0005-id-backbone-cosing-ref.md`,
> Accepted). Le bloc `identity` (`cosingRef`, `cas`, `ec`, `inchikey`, `functions`)
> est désormais porté par **948/948** records (`npm run backfill:identity` →
> `build-evidence-db` → merged DB) : 896 matchés CosIng, 52 `secondClass` (sans
> `ref`, clé de repli = INCI normalisé). Défauts 1 et 2 ci-dessous adressés.
> **P1 fiche réalisé** (commit suivant) : `npm run build:fiches` →
> `data/ingredients/generated/CATALOG.md`, vue lisible régénérable du record merged,
> groupée par tier *curaté* (569) vs *reconnu* (379) — le catalogue à deux étages
> tombe du rendu. Reste ouvert : P1 épaissir-régulatoire (CELEX + Canada dans le
> record). Tableau ci-dessous = état pré-P0.

**Constat central : la fiche encyclopédique est déjà produite, puis jetée.** Le
pipeline `npm run dossier` génère un bloc `identity` riche
(`cosing{cas, ec, functions, ref, synonyms}` + `pubchem{cid, formula, inchikey}`),
mais la promotion vers `data/ingredients/ingredients.jsonl` l'aplatit : il ne
reste que le risque. Les dossiers sont des artefacts transients (gitignored), donc
la donnée la plus riche disparaît après usage.

Mesures (951 entrées dans `ingredients.jsonl`, dont ~169 stubs) :

| pilier de l'objectif        | présent dans la DB finale ?                              |
| --------------------------- | -------------------------------------------------------- |
| fonction (« ce qu'il fait ») | **non — 0/951** ont un champ function                   |
| nom légal / CAS / EC        | **non — 0/951** ont cas/ec                              |
| régulé (annexe, limite, SCCS) | quasi-non — `regulatory` plat (`status` seul ; limite sur 25/951) |
| alias / autres noms         | non joint au record (île séparée `aliases.jsonl`)        |

Trois défauts structurels :

1. **Promotion destructrice** — l'identité du dossier n'atteint pas le record curaté.
2. **Pas de colonne vertébrale d'ID** — evidence (clé = INCI string), aliases, et
   CosIng (clé = `normalize`, possède un `ref`) sont trois îles jamais jointes.
3. **Fiche non matérialisée** — le livrable phare (la page qu'on lit) n'est durable
   nulle part.

Côté sources : le vrai moteur d'identité/fonction est **CosIng + PubChem** (déjà
câblés dans `dossier`), pas les PDF légaux. Les gros PDF (96/335, OJ L132) sont
redondants avec CosIng ; 2019/701 est abrogé (→ 32022D0677) ; le txt Canada n'est
pas encore ingéré en `regulatoryStatusByRegion.CA`. Voir la section précédente.

### Quoi faire (résultats visés, par levier)

- **P0 — Cesser de jeter l'identité.** Le record d'ingrédient doit porter le bloc
  identité+fonction que `dossier` produit déjà (cas, ec, functions, synonymes,
  inchikey, ref CosIng) ; rendre la promotion conservatrice.
- **P0 — Choisir une colonne vertébrale d'ID** (ref CosIng ou InChIKey) pour
  accrocher identité / alias / régulatoire / preuves / fonction au même endroit.
  **Décidé : `docs/adr/0005-id-backbone-cosing-ref.md` → CosIng `ref`** (InChIKey
  impossible comme clé universelle : pas de clé pour extraits/mélanges/polymères).
- **P1 — Matérialiser la fiche** ✅ — `CATALOG.md` (vue dérivée régénérable du
  record merged, `npm run build:fiches`), pas un dossier transient gitignored.
- **P1 — Catalogue à deux étages explicite** ✅ — rendu par tier *reconnu*
  (identité seule) vs *curaté* (preuves risque/bénéfice) dans `CATALOG.md`.
- **P1 — Épaissir le régulatoire** : ~ — la fiche (`CATALOG.md`) affiche désormais
  l'index officiel CELEX/Canada (annexe + limite) à côté du verdict curé, joint en
  lecture seule depuis `regulatory.lookup.json` (38/948 overlap ; curated/officiel
  restent séparés). Porter l'officiel *sur le record* est **différé** par
  `docs/adr/0006-official-regulatory-record-backfill.md` (faible rendement, change
  les notes runtime). Reste ouvert : peupler `dossier.regulatory` (null aujourd'hui).
- **P2 — Fonction « ce qu'il fait » en première classe** (CosIng `functions[]` +
  courte prose) — c'est le titre de la fiche.
- **P2 — Assumer le rayon documentaire** : dropper 96/335 + OJ L132 (CosIng
  supersede), remplacer 2019/701 abrogé par 32022D0677 si besoin d'une autorité
  noms-labelling, ingérer le txt Canada en CA structuré.

Fil rouge : le moteur (dossier + CosIng + PubChem) est déjà bâti, juste débranché
de la sortie. Le levier n'est pas plus de données — c'est arrêter d'en détruire et
leur donner une colonne vertébrale.
