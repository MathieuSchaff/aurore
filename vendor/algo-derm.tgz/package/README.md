# algo-derm

`algo-derm` is a TypeScript library that analyzes an INCI list and returns a dermatology-oriented product assessment.

It does **not** infer efficacy. It estimates **risk-oriented tolerance signals** across six axes:

- `irritation`
- `allergenicity`
- `comedogenicity`
- `dryness`
- `photosensitivity`
- `fungalAcne` (Pityrosporum folliculitis / Malassezia)

This README documents the **current implementation state in the codebase**, not the aspirational V2 design described in [docs/ENGINE_V2_MATHEMATICS.md](docs/archive/ENGINE_V2_MATHEMATICS.md).

## Documentation

The documentation hub is [docs/README.md](docs/README.md).

Use it to find the current roadmap, data pipeline, curation checklist, regulatory process, and archived session notes.

For a simple "where do I find this information?" entry point, see [WHERETOFIND/README.md](WHERETOFIND/README.md).

## What The Library Does Today

```
INCI string
  └─ parser.ts          split + normalize
       └─ matching.ts   alias index → curated DB match + heuristic fallback
            └─ productScoring.ts   per-axis risk · benefit · confidence
                 └─ productAssessment.ts   interactions · regulatory notes
                      └─ ProductAssessment   { overallRisk, rating, tags, ... }
```

Given an INCI string or ingredient array, the library:

1. splits and normalizes ingredient names,
2. matches ingredients against an evidence database with alias support, botanical fallback, and a small common-name alias table,
3. estimates likely concentration importance from INCI position,
4. applies profile and context multipliers,
5. applies a small set of data-driven interaction rules,
6. falls back to pattern heuristics for some unmatched fragrance / allergen / essential-oil cases,
7. returns a structured product assessment with risk scores, confidence, contributors, coverage, regulatory notes, and limitations.

There are **two analysis paths** in the code:

1. `analyzeINCI()` / `aggregateProductRisk()`
   This is the main structured product assessment path.
2. `analyzeINCIProbabilistic()`
   This is an alternative logistic-scoring path used mainly for benchmarking and threshold calibration.

These two paths now share some lower-level building blocks:

- alias/classification matching,
- exposure multipliers,
- driver-axis extraction,
- public concentration-estimate shaping.

## Default Evidence Database

`analyzeINCI()` defaults to `MERGED_EVIDENCE_DB`, the curated dataset shipped from `data/ingredient_evidence.merged.json` (>500 entries). The smaller `SAMPLE_EVIDENCE_DB` (~10 entries) is available from `algo-derm/engine` for demos and tests and remains opt-in via the `evidenceDatabase` option.

Coverage and confidence are still bounded by what is curated. Ingredients absent from the dataset still lower confidence rather than hide risk.

## Installation

```bash
npm install algo-derm
```

## Quick Start

```ts
import { analyzeINCI } from "algo-derm";

const result = analyzeINCI(
  "Aqua, Alcohol Denat, Glycolic Acid, Citrus Limon Peel Oil, Parfum, Limonene",
  {
    profile: { sensitiveSkin: true },
    context: { leaveOn: true, formulaType: "serum", estimatedPH: 3.5 },
  },
);

console.log(result.overallRisk);
console.log(result.rating);
console.log(result.confidence);
console.log(result.explanation.topRiskAxis);
console.log(result.explanation.topDrivers);
console.log(result.coverage);
console.log(result.regulatoryNotes);
console.log(result.notes);
```

## Overriding The Evidence Database

The package ships the merged dataset as the default. To use a custom or minimal database, pass `evidenceDatabase` explicitly:

```ts
import { analyzeINCI } from "algo-derm";
import { SAMPLE_EVIDENCE_DB } from "algo-derm/engine";

const result = analyzeINCI("Aqua, Alcohol Denat, Parfum", {
  evidenceDatabase: SAMPLE_EVIDENCE_DB, // or your own Record<string, IngredientEvidence>
  context: { leaveOn: true, formulaType: "serum" },
});
```

## Public API

Stable top-level exports:

```ts
import {
  analyzeINCI,    // full product assessment → ProductAssessment
  tagProduct,     // product-level boolean tags (sans_parfum, peaux_sensibles, ...) → ProductTag[]
  ingredientTags, // per-ingredient signal tags (fragrance, eu_restricted, ...) → IngredientTag[]
  splitINCI,
  normalize,
} from "algo-derm";
```

Advanced exports are available from the `algo-derm/engine` subpath for calibration,
benchmarking, custom data loading, and integration tests:

```ts
import {
  aggregateProductRisk,
  analyzeINCIProbabilistic,
  calibrateThresholds,
  runValidationBenchmark,
  runBenchmarkBySubpopulation,
  evaluateInteractions,
  buildAliasIndex,
  estimateConcentrationPosterior,
  MERGED_EVIDENCE_DB,
  SAMPLE_EVIDENCE_DB,
  SAMPLE_VALIDATION_CASES,
} from "algo-derm/engine";
```

Most application code should call `analyzeINCI(...)`. The advanced exports expose
engine internals intentionally, but their formulas and helper semantics may
change more often than the stable analyzer wrapper.

Main stable exported types include:

- `IngredientEvidence`
- `ProductAssessment`
- `ProductContext`
- `UserProfile`
- `RiskAxis`
- `ProductAxisRisk`
- `ProductInteraction`
- `IngredientProbability`
- `MatchedEvidence`
- `HeuristicFlag`
- `ScoreExplanation`
- `ProductTag` — product-level tag returned by `tagProduct`
- `IngredientTag` — per-ingredient tag returned by `ingredientTags`

### `tagProduct(assessment, rawIngredients)`

Returns product-level boolean tags from a pre-computed `ProductAssessment`. Tags answer "does this product qualify as X?" (e.g. `sans_parfum`, `hypoallergenique`, `peaux_sensibles`).

```ts
import { analyzeINCI, tagProduct, splitINCI } from "algo-derm";

const inci = "Aqua, Parfum, Sodium Lauryl Sulfate, Glycerin";
const assessment = analyzeINCI(inci);
const tags = tagProduct(assessment, splitINCI(inci));
// [
//   { id: "sans_parfum", label: "Sans parfum", present: false, confidence: 0.82, ... },
//   { id: "peaux_sensibles", label: "Convient aux peaux sensibles", present: false, ... },
//   { id: "vegan", label: "Vegan", present: true, confidence: 0.91, ... },
//   { id: "grossesse_risque", label: "Grossesse: ingrédient déconseillé", present: false, ... },
//   ...
// ]
```

**TAG_DEFS v7 additions** — two MAPPED_TAGS were added in v7 to centralise detection logic previously in downstream consumers:

- **`vegan`** (`present: true` when no animal-derived INCI pattern found and the formula has ≥ 5 ingredients). Consumer should treat `present: false` as "unknown, not a positive vegan claim" — INCI absence detection is precision-first.
- **`grossesse_risque`** (`present: true` when a known pregnancy contraindication is detected). Consumer should map this to an explicit "avoid" signal. Tier 1: retinoids (any position), hydroquinone, formaldehyde donors. Tier 2: BHA leave-on top 10 (`assessment.context.leaveOn`), oxybenzone/homosalate in sunscreen formulas (`assessment.context.formulaType === "sunscreen"`), risky essential oils top 8 (genus + "oil" co-occurrence).

Both new tags use `assessment.context` (exposed in `ProductAssessment` since v7 — see Output Model).

### `ingredientTags(assessment)`

Returns per-ingredient signal tags — which specific ingredient triggered what concern. Useful for building product catalogs or filtering UIs without exposing raw scores.

```ts
import { analyzeINCI, ingredientTags } from "algo-derm";

const tags = ingredientTags(analyzeINCI("Aqua, Parfum, Retinol, Phenoxyethanol"));
// [
//   { ingredient: "Parfum",         tag: "fragrance" },
//   { ingredient: "Parfum",         tag: "eu_restricted" },
//   { ingredient: "Retinol",        tag: "eu_restricted", detail: "max 0.3%, leave-on only" },
//   { ingredient: "Phenoxyethanol", tag: "eu_restricted", detail: "max 1%" },
// ]
```

Possible `tag` values:
- Heuristic families: `fragrance`, `fragrance_allergen`, `essential_oil`, `paraben`, `sulfate_surfactant`, `formaldehyde_donor`, `isothiazolinone`, `denatured_alcohol`, `silicone`, `mineral_oil`, `soap`, `propylene_glycol`, `menthol`, `alkanolamide`
- Regulatory: `eu_restricted`, `eu_prohibited`, `ca_restricted`, `ca_prohibited`

Advanced engine types such as `InteractionRule`, `ProbabilisticAnalysis`, and
`ValidationMetrics` are exported from `algo-derm/engine`.

## Input Model

### `analyzeINCI(inci, options)`

Accepted `inci` input:

- comma-separated string
- `string[]`

Accepted options:

```ts
type AnalyzeOptions = {
  evidenceDatabase?: Record<string, IngredientEvidence>;
  profile?: UserProfile;
  context?: ProductContext;
};
```

### `ProductContext`

```ts
type ProductContext = {
  leaveOn: boolean;
  formulaType?: "serum" | "cream" | "gel" | "cleanser" | "lotion";
  estimatedPH?: number;
};
```

### `UserProfile`

```ts
type UserProfile = {
  sensitiveSkin?: boolean;
  acneProne?: boolean;
  rosacea?: boolean;
  pregnant?: boolean;
};
```

## Output Model

The main path returns `ProductAssessment`.

```
ProductAssessment
 ├─ overallRisk: 0..1          global bounded risk score
 ├─ rating: low|medium|high    fixed thresholds (< 0.33 / < 0.66 / ≥ 0.66)
 ├─ confidence: 0..1           drops when many ingredients are unknown
 ├─ confidenceLabel            low | medium | high
 ├─ context: ProductContext    context passed to analyzeINCI (leaveOn, formulaType, …)
 │                              exposed so tagProduct MAPPED_TAGS can apply context-aware
 │                              rules without a separate context argument
 │
 ├─ productAxisRisk            one entry per risk axis
 │    └─ { axis, risk: 0..1, confidence, drivers[] }
 │         drivers[]: [{ ingredient, contribution, source }]
 │                    source = matchedEvidence | heuristicFlag | interaction
 │
 ├─ productBenefits            same shape — soothing, hydrating, barrierSupport, …
 │    └─ { axis, score: 0..1, drivers[] }
 │
 ├─ explanation
 │    ├─ topRiskAxis           axis with highest risk
 │    ├─ topDrivers[]          sorted by |contribution|, all sources mixed
 │    ├─ topBenefitAxis
 │    ├─ topBenefitDrivers[]
 │    ├─ confidenceFactors[]   reasons confidence was lowered
 │    └─ limitationNotes[]
 │
 ├─ coverage
 │    ├─ matched               ingredients found in evidence DB
 │    ├─ heuristicOnly         matched by pattern only (no evidence record)
 │    ├─ unmatched             unknown to both DB and heuristics
 │    ├─ total
 │    ├─ ratio                 matched / total
 │    └─ confidencePenalty     0..1 subtracted from confidence
 │
 ├─ contributors[]             per-ingredient probability from matched evidence
 ├─ interactions[]             fired interaction rules with their adjustment
 ├─ matchedEvidence[]          ingredients resolved to a curated evidence record
 ├─ heuristicFlags[]           pattern-detected ingredients (fragrance, paraben, …)
 ├─ unmatchedIngredients[]     ingredients with no match at all
 ├─ regulatoryNotes[]          prohibited / restricted notes from evidence records
 └─ notes[]                    human-readable limitation strings
```

### Top-Level Fields

| Field | Meaning |
|---|---|
| `overallRisk` | Global bounded risk score in `0..1` |
| `rating` | `low`, `medium`, or `high` using fixed thresholds |
| `productAxisRisk` | Per-axis risk, confidence, and drivers |
| `confidence` | Aggregate confidence in `0..1` |
| `confidenceLabel` | `low`, `medium`, `high` |
| `context` | `ProductContext` used during analysis (leaveOn, formulaType, …) — available to `tagProduct` MAPPED_TAGS for context-aware rules |
| `coverage` | How many ingredients were matched, heuristic-only, or unmatched |
| `explanation` | Top axis, top drivers, confidence factors, limitation notes |
| `contributors` | Ingredient-level matched contributors |
| `interactions` | Fired interaction rules |
| `matchedEvidence` | Ingredients matched to evidence |
| `unmatchedIngredients` | Ingredients with no evidence and no heuristic match |
| `heuristicFlags` | Pattern-based detections used when evidence is missing |
| `regulatoryNotes` | Prohibited / restricted notes from evidence records |
| `notes` | Human-readable limitations |

### Risk Labels

Fixed rating thresholds:

- `low` if risk `< 0.33`
- `medium` if risk `< 0.66`
- `high` otherwise

Confidence label thresholds:

- `low` if confidence `< 0.45`
- `medium` if confidence `< 0.75`
- `high` otherwise

## How The Current Algorithm Works

This section describes the implementation in `src/`, not the future V2 design docs.

### 1. Parsing And Normalization

The parser is intentionally simple:

- `splitINCI()` splits on commas and strips trailing sentence punctuation (`.`, `;`) per token
- `normalize()` lowercases, strips accents, removes most punctuation, compresses whitespace, and keeps basic alphanumerics plus `/` and `-`

This is enough for practical alias matching but it is not a full INCI grammar.

### 2. Evidence Matching

The engine builds an alias index from:

- record key
- canonical `evidence.inci`
- optional `aliases`
- a small JSON table of common-name / marketing aliases when the canonical INCI exists in the loaded database

It also performs a small botanical normalization trick by stripping words like `leaf`, `flower`, and `peel` for some oil/extract matching.

If an ingredient cannot be matched to evidence:

1. heuristic rules are checked,
2. if no heuristic matches, the ingredient is treated as unmatched and lowers confidence.

### 3. Concentration Estimation

Concentration is **not** inferred from a full formula model. The current implementation uses a **per-ingredient Beta posterior estimate** based on:

1. INCI position prior,
2. formula-type prior tweaks,
3. leave-on vs rinse-off scaling,
4. and pseudo-evidence based on ingredient family or curated min/max concentration metadata.

Important current constants:

- first ingredient prior mean: about `70%`
- second ingredient prior mean: about `30%`
- early mid-list ingredients: around `15%`
- mid-list ingredients: around `7%`
- tail ingredients: around `2%`

Ingredient-family pseudo-evidence is currently coarse:

- `solvent`
- `active`
- `preservative`
- `uv_filter`
- `allergen`
- `default`

The output of this stage is:

- `meanPct`
- `ciLowPct`
- `ciHighPct`
- `weight`

Important limitation:

These concentration estimates are **independent approximations**. They do **not** enforce mass conservation across the full formula and do **not** reconstruct a full composition simplex.

### 4. Evidence Weighting

Each evidence record receives a confidence weight:

- `A = 1.00`
- `B = 0.85`
- `C = 0.65`
- `D = 0.45`

Study-count adjustments:

- `> 10` studies: `+0.05`
- `< 3` studies: `-0.10`
- floor: `0.30`

These weights are internal calibration constants. They are not presented in code as externally validated clinical coefficients.

### 5. Axis-Level Ingredient Signal

For each matched ingredient and each axis, the engine computes:

1. normalized axis risk from `evidence.risk[axis] / 5`,
2. concentration effect using `sqrt(concentration.weight)`,
3. exposure multiplier from leave-on / rinse-off context,
4. profile multiplier for the relevant user profile,
5. evidence weight.

In simplified form:

```text
axisSignal
  = axisRisk
  × sqrt(concentrationWeight)
  × exposureMultiplier
  × profileAxisMultiplier
  × evidenceWeight
```

Profile multipliers are axis-specific:

- `sensitiveSkin` boosts `irritation` and `dryness`
- `rosacea` boosts `irritation` and `photosensitivity`
- `acneProne` boosts `comedogenicity` and `fungalAcne`
- `pregnant` boosts `photosensitivity`

### 6. Interaction Rules

Interactions are currently **data-driven additive adjustments** from `data/rules/interaction_rules.json`.

Current shipped rule types include:

- alcohol + fragrance
- alcohol + fragrance allergen
- acid + alcohol
- multiple essential oils
- niacinamide + glycerin mitigation
- AHA low-pH rule when `estimatedPH < 4`
- BHA low-pH rule when `estimatedPH < 4`

Mitigation interactions can also appear in `explanation.topDrivers` with a negative signed contribution when they materially affect the explanation.

Important limitation:

These are discrete additive rules, not concentration-aware mechanistic simulations.

### 7. Heuristic Rules

When evidence is missing, the engine can still emit pattern-based heuristic flags for:

- fragrance
- fragrance allergen
- essential oil / botanical oil patterns

Heuristic signals are scaled down relative to curated evidence and are kept separate in the explanation model.

### 8. Axis Aggregation

For each axis, the engine builds a driver set from:

- matched evidence contributors
- heuristic flags
- matched interactions

Axis score:

```text
axisRisk
  = 0.65 × max(driverContribution)
  + 0.35 × mean(driverContribution)
  + interactionAdjustment
```

Then the result is clamped to `0..1`.

This makes the algorithm **max-dominated**, not purely additive.

### 9. Overall Product Aggregation

Overall risk combines the axis scores and positive interactions:

```text
overallRisk
  = 0.60 × max(axisRisks)
  + 0.40 × mean(axisRisks)
  + 0.25 × positiveInteractionAdjustment
```

Then the result is clamped to `0..1`.

This means a single dominant high-risk axis has substantial influence on the final product score.

### 10. Confidence Model

Confidence is influenced by:

1. average confidence of matched contributors,
2. matched coverage ratio,
3. heuristic-only ingredient ratio,
4. unmatched ingredient penalty.

In simplified form:

```text
confidence
  = averageContributorConfidence × matchedRatio
  + heuristicRatio × 0.20
  - unmatchedRatio × 0.25
```

Consequences:

- unmatched ingredients reduce confidence
- heuristic-only signals add some weak confidence but do not behave like real evidence
- low-coverage products can still produce risk scores, but those scores should be interpreted cautiously

## The Alternative Probabilistic Path

`analyzeINCIProbabilistic()` is a separate scoring path used by benchmarking and calibration code.

It:

1. computes a weighted multi-axis signal per ingredient,
2. applies a logistic transform,
3. averages ingredient probabilities,
4. adds interaction adjustment,
5. computes a simple confidence-dependent CI width.

This path returns `ProbabilisticAnalysis`, not `ProductAssessment`.

It is useful for threshold calibration and validation utilities, but it is not the same output model as `analyzeINCI()`.

## Current Dataset State

Repository merged dataset stats from `data/ingredient_evidence.merged.json`:

- `521` evidence records
- `349` records with aliases
- `521` records with regulatory status
- axis coverage:
  - `irritation`: `245`
  - `allergenicity`: `165`
  - `comedogenicity`: `33`
  - `dryness`: `75`
  - `photosensitivity`: `17`
- evidence levels:
  - `A`: `253`
  - `B`: `214`
  - `C`: `54`

The published package ships this merged dataset and `analyzeINCI()` loads it as the default `evidenceDatabase`. `SAMPLE_EVIDENCE_DB` is available from `algo-derm/engine` for demos and tests.

## Validation And Tests

Current automated testing is **smoke-level**, not full clinical validation.

What is covered today:

- bounded output checks
- regulatory-note behavior
- benchmark metric shape and bounds
- calibration threshold ordering
- separation of matched evidence / heuristic flags / unmatched ingredients
- sample benchmark non-regression floor for `macroF1`
- convergence between the structured and probabilistic paths for contributor drivers and public concentration estimates

What the sample benchmark actually is:

- `7` sample validation cases in `src/engine/sampleValidationCases.ts`
- benchmarked through `runValidationBenchmark()`
- grouped by profile through `runBenchmarkBySubpopulation()`

This is useful for regression control, but it is **not** enough to claim broad clinical validation.

## What The Library Does Not Do

The current implementation does **not** do the following:

- enforce whole-formula concentration mass conservation
- run Monte Carlo or Latin hypercube sampling
- implement Dempster-Shafer evidence fusion
- model molecular weight penetration, Henderson-Hasselbalch chemistry, or flux integrals
- learn from user feedback
- infer emulsion structure, stability, preservation robustness, packaging effects, or raw material grade
- infer exact concentration from INCI order
- model full skincare-routine interactions across multiple products

Those ideas are discussed in docs such as [docs/ENGINE_V2_MATHEMATICS.md](docs/archive/ENGINE_V2_MATHEMATICS.md), but they are **not** the current production implementation.

## Repository Structure

```text
src/
  analyzer.ts                 public analyzeINCI wrapper
  parser.ts                   INCI splitting and normalization
  index.ts                    public exports
  engine/
    productAssessment.ts      product assessment orchestrator
    matching.ts               alias index, classification, heuristics
    productScoring.ts         risk, benefit, coverage, confidence scoring
    productExplanation.ts     ScoreExplanation assembly
    regulatory.ts             regulatory note formatting (exports formatRegulatoryDetail)
    regulatoryAlerts.ts       prohibited/restricted lookup from official lists (CELEX + HC)
    axes.ts                   canonical risk/benefit axes
    probabilistic.ts          alternate probabilistic path
    sharedSignals.ts          shared exposure/driver/concentration helpers
    concentration.ts          position-based concentration estimation
    interactions.ts           rule matching and validation
    calibration.ts            rating-threshold search
    validation.ts             confusion matrix and F1 metrics
    benchmark.ts              benchmark orchestration
    sampleEvidence.ts         small demo evidence database with concentration bounds
    mergedEvidence.ts         loads the curated merged dataset as the default
    sampleValidationCases.ts  tiny benchmark set
    constants.ts              calibrated weights and thresholds
    utils.ts                  evidence weighting, profile multipliers, labels
data/
  rules/
    common_name_aliases.json  marketing/common-name alias table
    heuristic_rules.json      pattern heuristics
    interaction_rules.json    additive interaction rules
  templates/                  dataset source templates
  ingredient_evidence.merged.json
  evidence_manifest.json
scripts/
  build-evidence-db.mjs       CSV → curated.generated.json
  validate-evidence-db.mjs    schema validation on generated JSON
  merge-evidence-sources.mjs  merge manifest sources → merged.json
  validate-manifest.mjs       manifest integrity check
  tag-products.mjs            batch-tag a product list (JSON/CSV) → ingredientTags per product
test/
  *.test.mjs                  smoke tests against dist/
docs/
  README.md                    documentation index
  CODEBASE_MAP.md              source layout and module responsibilities
  ROADMAP.md                   current status and priorities
  REGULATORY_DATA.md           regulatory curation process
  HOW_TO_CURATE_INGREDIENT.md  practical ingredient curation workflow
  archive/ENGINE_V2_MATHEMATICS.md    aspirational future design (not current state)
  DATA_PIPELINE.md            dataset workflow
  CURATION_CHECKLIST.md       curation process
  archive/                     historical prompts and scratch notes
```

## Development Commands

```bash
npm run build
npm run typecheck
npm run test:smoke
npm run build:dataset
npm run validate:dataset
npm run report:dataset
npm run validate:manifest
npm run merge:dataset
npm run check:all
```

Command meanings:

- `build`: compile TypeScript to `dist/`
- `typecheck`: strict type check without output
- `test:smoke`: build and run the Node test suite
- `build:dataset`: CSV template to generated JSON
- `validate:dataset`: validate generated dataset structure
- `report:dataset`: print curation coverage stats
- `validate:manifest`: validate evidence manifest
- `merge:dataset`: merge manifest-listed evidence sources
- `check:all`: full local quality gate

## Guidance For Humans And LLMs

If you are trying to understand the current algorithm quickly, the right mental model is:

1. this is a **rule-and-weight engine**, not a learned model,
2. the main path is a **structured per-axis scorer** with confidence and explanation,
3. concentration is a **Bayesian-style positional approximation**, not a full compositional reconstruction,
4. unmatched ingredients mostly reduce confidence unless heuristic rules catch them,
5. interaction modeling is **small, explicit, and additive**,
6. the default bundled database is the curated merged dataset (`MERGED_EVIDENCE_DB`); `SAMPLE_EVIDENCE_DB` is opt-in.

If you need the future intended direction, read [docs/ENGINE_V2_MATHEMATICS.md](docs/archive/ENGINE_V2_MATHEMATICS.md) separately and treat it as roadmap material, not as a description of the code that runs today.
